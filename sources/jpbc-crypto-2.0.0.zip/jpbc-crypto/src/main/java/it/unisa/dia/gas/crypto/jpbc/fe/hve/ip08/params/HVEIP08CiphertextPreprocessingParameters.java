package it.unisa.dia.gas.crypto.jpbc.fe.hve.ip08.params;

/**
 * @author Angelo De Caro (jpbclib@gmail.com)
 */
public class HVEIP08CiphertextPreprocessingParameters extends HVEIP08KeyParameters {

    public HVEIP08CiphertextPreprocessingParameters(HVEIP08Parameters parameters) {
        super(false, parameters);
    }

}
